from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from enum import IntEnum, auto
import math
from pathlib import Path
import sys
from typing import Iterator, Literal, Self, TypeIs, overload, Union
from . import resources

import pygame as pg

ColorValue = tuple[int, int, int] | tuple[int, int, int, int]

class _KeyBase(IntEnum):
    def __str__(self) -> str:
        return f"{type(self).__name__}.{self.name}"

    @classmethod
    def from_pygame(cls, value: int | Self) -> Self | int:
        if isinstance(value, cls):
            return value
        try:
            return cls(value)
        except ValueError:
            return value


class Key(_KeyBase):
    DIGIT_0 = pg.K_0
    DIGIT_1 = pg.K_1
    DIGIT_2 = pg.K_2
    DIGIT_3 = pg.K_3
    DIGIT_4 = pg.K_4
    DIGIT_5 = pg.K_5
    DIGIT_6 = pg.K_6
    DIGIT_7 = pg.K_7
    DIGIT_8 = pg.K_8
    DIGIT_9 = pg.K_9
    AC_BACK = pg.K_AC_BACK
    AMPERSAND = pg.K_AMPERSAND
    ASTERISK = pg.K_ASTERISK
    AT = pg.K_AT
    BACKQUOTE = pg.K_BACKQUOTE
    BACKSLASH = pg.K_BACKSLASH
    BACKSPACE = pg.K_BACKSPACE
    BREAK = pg.K_BREAK
    CAPSLOCK = pg.K_CAPSLOCK
    CARET = pg.K_CARET
    CLEAR = pg.K_CLEAR
    COLON = pg.K_COLON
    COMMA = pg.K_COMMA
    CURRENCYSUBUNIT = pg.K_CURRENCYSUBUNIT
    CURRENCYUNIT = pg.K_CURRENCYUNIT
    DELETE = pg.K_DELETE
    DOLLAR = pg.K_DOLLAR
    DOWN = pg.K_DOWN
    END = pg.K_END
    EQUALS = pg.K_EQUALS
    ESCAPE = pg.K_ESCAPE
    EURO = pg.K_EURO
    EXCLAIM = pg.K_EXCLAIM
    F1 = pg.K_F1
    F10 = pg.K_F10
    F11 = pg.K_F11
    F12 = pg.K_F12
    F13 = pg.K_F13
    F14 = pg.K_F14
    F15 = pg.K_F15
    F2 = pg.K_F2
    F3 = pg.K_F3
    F4 = pg.K_F4
    F5 = pg.K_F5
    F6 = pg.K_F6
    F7 = pg.K_F7
    F8 = pg.K_F8
    F9 = pg.K_F9
    GREATER = pg.K_GREATER
    HASH = pg.K_HASH
    HELP = pg.K_HELP
    HOME = pg.K_HOME
    INSERT = pg.K_INSERT
    KP_0 = pg.K_KP0
    KP_1 = pg.K_KP1
    KP_2 = pg.K_KP2
    KP_3 = pg.K_KP3
    KP_4 = pg.K_KP4
    KP_5 = pg.K_KP5
    KP_6 = pg.K_KP6
    KP_7 = pg.K_KP7
    KP_8 = pg.K_KP8
    KP_9 = pg.K_KP9
    KP_DIVIDE = pg.K_KP_DIVIDE
    KP_ENTER = pg.K_KP_ENTER
    KP_EQUALS = pg.K_KP_EQUALS
    KP_MINUS = pg.K_KP_MINUS
    KP_MULTIPLY = pg.K_KP_MULTIPLY
    KP_PERIOD = pg.K_KP_PERIOD
    KP_PLUS = pg.K_KP_PLUS
    LALT = pg.K_LALT
    LCTRL = pg.K_LCTRL
    LEFT = pg.K_LEFT
    LEFTBRACKET = pg.K_LEFTBRACKET
    LEFTPAREN = pg.K_LEFTPAREN
    LESS = pg.K_LESS
    LGUI = pg.K_LGUI
    LMETA = pg.K_LMETA
    LSHIFT = pg.K_LSHIFT
    LSUPER = pg.K_LSUPER
    MENU = pg.K_MENU
    MINUS = pg.K_MINUS
    MODE = pg.K_MODE
    NUMLOCK = pg.K_NUMLOCK
    NUMLOCKCLEAR = pg.K_NUMLOCKCLEAR
    PAGEDOWN = pg.K_PAGEDOWN
    PAGEUP = pg.K_PAGEUP
    PAUSE = pg.K_PAUSE
    PERCENT = pg.K_PERCENT
    PERIOD = pg.K_PERIOD
    PLUS = pg.K_PLUS
    POWER = pg.K_POWER
    PRINT = pg.K_PRINT
    PRINTSCREEN = pg.K_PRINTSCREEN
    QUESTION = pg.K_QUESTION
    QUOTE = pg.K_QUOTE
    QUOTEDBL = pg.K_QUOTEDBL
    RALT = pg.K_RALT
    RCTRL = pg.K_RCTRL
    RETURN = pg.K_RETURN
    RGUI = pg.K_RGUI
    RIGHT = pg.K_RIGHT
    RIGHTBRACKET = pg.K_RIGHTBRACKET
    RIGHTPAREN = pg.K_RIGHTPAREN
    RMETA = pg.K_RMETA
    RSHIFT = pg.K_RSHIFT
    RSUPER = pg.K_RSUPER
    SCROLLLOCK = pg.K_SCROLLLOCK
    SEMICOLON = pg.K_SEMICOLON
    SLASH = pg.K_SLASH
    SPACE = pg.K_SPACE
    SYSREQ = pg.K_SYSREQ
    TAB = pg.K_TAB
    UNDERSCORE = pg.K_UNDERSCORE
    UNKNOWN = pg.K_UNKNOWN
    UP = pg.K_UP
    A = pg.K_a
    B = pg.K_b
    C = pg.K_c
    D = pg.K_d
    E = pg.K_e
    F = pg.K_f
    G = pg.K_g
    H = pg.K_h
    I = pg.K_i
    J = pg.K_j
    K = pg.K_k
    L = pg.K_l
    M = pg.K_m
    N = pg.K_n
    O = pg.K_o
    P = pg.K_p
    Q = pg.K_q
    R = pg.K_r
    S = pg.K_s
    T = pg.K_t
    U = pg.K_u
    V = pg.K_v
    W = pg.K_w
    X = pg.K_x
    Y = pg.K_y
    Z = pg.K_z


class MouseButton(_KeyBase):
    LEFT = pg.BUTTON_LEFT
    MIDDLE = pg.BUTTON_MIDDLE
    RIGHT = pg.BUTTON_RIGHT
    WHEELUP = pg.BUTTON_WHEELUP
    WHEELDOWN = pg.BUTTON_WHEELDOWN
    X1 = pg.BUTTON_X1
    X2 = pg.BUTTON_X2


class ControllerButton(_KeyBase):
    A = pg.CONTROLLER_BUTTON_A
    B = pg.CONTROLLER_BUTTON_B
    X = pg.CONTROLLER_BUTTON_X
    Y = pg.CONTROLLER_BUTTON_Y
    BACK = pg.CONTROLLER_BUTTON_BACK
    GUIDE = pg.CONTROLLER_BUTTON_GUIDE
    START = pg.CONTROLLER_BUTTON_START
    LEFTSTICK = pg.CONTROLLER_BUTTON_LEFTSTICK
    RIGHTSTICK = pg.CONTROLLER_BUTTON_RIGHTSTICK
    LEFTSHOULDER = pg.CONTROLLER_BUTTON_LEFTSHOULDER
    RIGHTSHOULDER = pg.CONTROLLER_BUTTON_RIGHTSHOULDER
    LEFTTRIGGER = pg.CONTROLLER_BUTTON_MAX + 1
    RIGHTTRIGGER = pg.CONTROLLER_BUTTON_MAX + 2
    DPAD_UP = pg.CONTROLLER_BUTTON_DPAD_UP
    DPAD_DOWN = pg.CONTROLLER_BUTTON_DPAD_DOWN
    DPAD_LEFT = pg.CONTROLLER_BUTTON_DPAD_LEFT
    DPAD_RIGHT = pg.CONTROLLER_BUTTON_DPAD_RIGHT


class InputProfile(IntEnum):
    KEYBOARD_MOUSE = -1
    CONTROLLER_0 = 0
    CONTROLLER_1 = 1
    CONTROLLER_2 = 2
    CONTROLLER_3 = 3


class BlendMode(_KeyBase):
    RGB_ADD = pg.BLEND_RGB_ADD
    "Adds the base colors to black (`(0, 0, 0)`)."
    RGB_SUBTRACT = pg.BLEND_RGB_SUB
    "Subtracts the base colors from white (`(255, 255, 255)`)."
    RGB_MULTIPLY = pg.BLEND_RGB_MULT
    "Converts the base colors to decimals between 0 and 1 (e.g. `(128, 0, 255) -> (0.5, 0, 1)`), and multiplies them."
    RGB_ALPHA_ADD = pg.BLEND_RGBA_ADD
    "Adds the base colors and transparancies to transparent black (`(0, 0, 0, 0)`)."
    RGB_ALPHA_SUBTRACT = pg.BLEND_RGBA_SUB
    "Subtracts the base colors and transparancies from opaque white (`(255, 255, 255, 255)`)."
    RGB_ALPHA_MULTIPLY = pg.BLEND_RGBA_MULT
    "Converts the base colors and transparancies to decimals between 0 and 1 (e.g. `(128, 0, 255, 102) -> (0.5, 0, 1, 0.4)`), and multiplies them."


KeyValue = Key | int
MouseButtonValue = MouseButton | int
ControllerButtonValue = ControllerButton | int


@dataclass
class InputAction:
    keys: set[KeyValue] = field(default_factory=set)
    mouse_buttons: set[MouseButtonValue] = field(default_factory=set)
    controller_buttons: set[ControllerButtonValue] = field(default_factory=set)
    profiles: set[InputProfile] | None = field(default_factory=set)


class InputState:
    def __init__(self):
        self.keys_pressed: set[KeyValue] = set()
        self.keys_pressed_last_frame: set[KeyValue] = set()
        self.mouse_buttons_pressed: set[MouseButtonValue] = set()
        self.mouse_buttons_pressed_last_frame: set[MouseButtonValue] = set()
        self.controller_buttons_pressed: dict[InputProfile, set[ControllerButtonValue]] = {}
        self.controller_buttons_pressed_last_frame: dict[InputProfile, set[ControllerButtonValue]] = {}
        self.controller_left_sticks: dict[InputProfile, FCoordinateValue] = {}
        self.controller_right_sticks: dict[InputProfile, FCoordinateValue] = {}
        self.controller_left_sticks_last_frame: dict[InputProfile, FCoordinateValue] = {}
        self.controller_right_sticks_last_frame: dict[InputProfile, FCoordinateValue] = {}
        self.mouse_pos: CoordinateValue = (0, 0)
        self.mouse_pos_last_frame: CoordinateValue = (0, 0)
        self.text_input: list[str] = []
        self.mouse_wheel: int = 0
        self.runtime: float = 0.0
        self.dt: float = 0.0
        self.quit = False

    def next_frame(self, dt: float):
        self.keys_pressed_last_frame = self.keys_pressed.copy()
        self.mouse_buttons_pressed_last_frame = self.mouse_buttons_pressed.copy()
        self.controller_buttons_pressed_last_frame = {profile: buttons.copy() for profile, buttons in self.controller_buttons_pressed.items()}
        self.controller_left_sticks_last_frame = self.controller_left_sticks.copy()
        self.controller_right_sticks_last_frame = self.controller_right_sticks.copy()
        self.mouse_pos_last_frame = self.mouse_pos
        self.dt = dt
        self.runtime += dt
        self.quit = False

    @property
    def key_downs(self) -> set[KeyValue]:
        return self.keys_pressed - self.keys_pressed_last_frame

    @property
    def key_ups(self) -> set[KeyValue]:
        return self.keys_pressed_last_frame - self.keys_pressed

    @property
    def mouse_downs(self) -> set[int]:
        return self.mouse_buttons_pressed - self.mouse_buttons_pressed_last_frame

    @property
    def mouse_ups(self) -> set[int]:
        return self.mouse_buttons_pressed_last_frame - self.mouse_buttons_pressed

    @property
    def mouse_delta(self) -> CoordinateValue:
        return (self.mouse_pos[0] - self.mouse_pos_last_frame[0], self.mouse_pos[1] - self.mouse_pos_last_frame[1])

    @property
    def controller_button_downs(self) -> dict[InputProfile, set[ControllerButtonValue]]:
        return {
            profile: buttons - self.controller_buttons_pressed_last_frame.get(profile, set())
            for profile, buttons in self.controller_buttons_pressed.items()
        }
    
    @property
    def controller_button_ups(self) -> dict[InputProfile, set[ControllerButtonValue]]:
        return {
            profile: self.controller_buttons_pressed_last_frame.get(profile, set()) - buttons
            for profile, buttons in self.controller_buttons_pressed.items()
        }
    
    @property
    def controller_left_stick_deltas(self) -> dict[InputProfile, FCoordinateValue]:
        return {
            profile: (
                self.controller_left_sticks.get(profile, (0.0, 0.0))[0] - self.controller_left_sticks_last_frame.get(profile, (0.0, 0.0))[0],
                self.controller_left_sticks.get(profile, (0.0, 0.0))[1] - self.controller_left_sticks_last_frame.get(profile, (0.0, 0.0))[1],
            )
            for profile in set(self.controller_left_sticks.keys()) | set(self.controller_left_sticks_last_frame.keys())
        }
    
    @property
    def controller_right_stick_deltas(self) -> dict[InputProfile, FCoordinateValue]:
        return {
            profile: (
                self.controller_right_sticks.get(profile, (0.0, 0.0))[0] - self.controller_right_sticks_last_frame.get(profile, (0.0, 0.0))[0],
                self.controller_right_sticks.get(profile, (0.0, 0.0))[1] - self.controller_right_sticks_last_frame.get(profile, (0.0, 0.0))[1],
            )
            for profile in set(self.controller_right_sticks.keys()) | set(self.controller_right_sticks_last_frame.keys())
        }


    def key_held(self, key: KeyValue, profile: InputProfile | None = None) -> bool:
        if profile is not None and profile is not InputProfile.KEYBOARD_MOUSE:
            return False
        return key in self.keys_pressed
    
    def key_up(self, key: KeyValue, profile: InputProfile | None = None) -> bool:
        if profile is not None and profile is not InputProfile.KEYBOARD_MOUSE:
            return False
        return key in self.key_ups
    
    def key_down(self, key: KeyValue, profile: InputProfile | None = None) -> bool:
        if profile is not None and profile is not InputProfile.KEYBOARD_MOUSE:
            return False
        return key in self.key_downs


    def mousebutton_held(self, mousebutton: MouseButtonValue, profile: InputProfile | None = None) -> bool:
        if profile is not None and profile is not InputProfile.KEYBOARD_MOUSE:
            return False
        return mousebutton in self.mouse_buttons_pressed
    
    def mousebutton_up(self, mousebutton: MouseButtonValue, profile: InputProfile | None = None) -> bool:
        if profile is not None and profile is not InputProfile.KEYBOARD_MOUSE:
            return False
        return mousebutton in self.mouse_ups
    
    def mousebutton_down(self, mousebutton: MouseButtonValue, profile: InputProfile | None = None) -> bool:
        if profile is not None and profile is not InputProfile.KEYBOARD_MOUSE:
            return False
        return mousebutton in self.mouse_downs
    
    
    def controllerbutton_held(self, controllerbutton: ControllerButtonValue, profile: InputProfile | None) -> bool:
        if profile is not None and profile is InputProfile.KEYBOARD_MOUSE:
            return False
        if profile is None:
            return any(controllerbutton in buttons for buttons in self.controller_buttons_pressed.values())
        return controllerbutton in self.controller_buttons_pressed.get(profile, set())
    
    def controllerbutton_up(self, controllerbutton: ControllerButtonValue, profile: InputProfile | None) -> bool:
        if profile is not None and profile is InputProfile.KEYBOARD_MOUSE:
            return False
        if profile is None:
            return any(controllerbutton in buttons for buttons in self.controller_button_ups.values())
        return controllerbutton in self.controller_button_ups.get(profile, set())
    
    def controllerbutton_down(self, controllerbutton: ControllerButtonValue, profile: InputProfile | None) -> bool:
        if profile is not None and profile is InputProfile.KEYBOARD_MOUSE:
            return False
        if profile is None:
            return any(controllerbutton in buttons for buttons in self.controller_button_downs.values())
        return controllerbutton in self.controller_button_downs.get(profile, set())


    def input_action_held(self, action: InputAction) -> bool:
        for profile in action.profiles or {None}:
            if any(self.key_held(key, profile) for key in action.keys):
                return True
            if any(self.mousebutton_held(mousebutton, profile) for mousebutton in action.mouse_buttons):
                return True
            if any(self.controllerbutton_held(controllerbutton, profile) for controllerbutton in action.controller_buttons):
                return True
        return False
    
    def input_action_up(self, action: InputAction) -> bool:
        for profile in action.profiles or {None}:
            if any(self.key_up(key, profile) for key in action.keys):
                return True
            if any(self.mousebutton_up(mousebutton, profile) for mousebutton in action.mouse_buttons):
                return True
            if any(self.controllerbutton_up(controllerbutton, profile) for controllerbutton in action.controller_buttons):
                return True
        return False
    
    def input_action_down(self, action: InputAction) -> bool:
        for profile in action.profiles or {None}:
            if any(self.key_down(key, profile) for key in action.keys):
                return True
            if any(self.mousebutton_down(mousebutton, profile) for mousebutton in action.mouse_buttons):
                return True
            if any(self.controllerbutton_down(controllerbutton, profile) for controllerbutton in action.controller_buttons):
                return True
        return False


CoordinateValue = tuple[int, int]
FCoordinateValue = tuple[float, float]
RectValue = Union[tuple[int, int, int, int], tuple[CoordinateValue, CoordinateValue], pg.Rect, "Rect"]
FRectValue = Union[tuple[float, float, float, float], tuple[FCoordinateValue, FCoordinateValue], "FRect"]

def _is_rect_xywh(arg) -> TypeIs[tuple[int, int, int, int]]:
    return isinstance(arg, tuple) and len(arg) == 4 and all(isinstance(scalar, int) for scalar in arg)

def _is_rect_topleft_size(arg) -> TypeIs[tuple[CoordinateValue, CoordinateValue]]:
    return isinstance(arg, tuple) and len(arg) == 2 and all(isinstance(point, tuple) and len(point) == 2 and all(isinstance(scalar, int) for scalar in point) for point in arg)

def _is_rect_rect_obj(arg) -> "TypeIs[pg.Rect | Rect]":
    return isinstance(arg, pg.Rect) or isinstance(arg, Rect)


def _is_frect_xywh(arg) -> TypeIs[tuple[float, float, float, float]]:
    return isinstance(arg, tuple) and len(arg) == 4 and all(isinstance(scalar, (int, float)) for scalar in arg)

def _is_frect_topleft_size(arg) -> TypeIs[tuple[FCoordinateValue, FCoordinateValue]]:
    return isinstance(arg, tuple) and len(arg) == 2 and all(isinstance(point, tuple) and len(point) == 2 and all(isinstance(scalar, float) for scalar in point) for point in arg)

def _is_frect_frect_obj(arg) -> "TypeIs[FRect]":
    return isinstance(arg, FRect)


@overload
def _validate_rect_args(args: tuple, frect: Literal[False] = False) -> tuple[int, int, int, int]: ...

@overload
def _validate_rect_args(args: tuple, frect: Literal[True]) -> tuple[float, float, float, float]: ...

def _validate_rect_args(args: tuple, frect: bool = False) -> tuple[int, int, int, int] | tuple[float, float, float, float]:
    if len(args) == 1:
        args = args[0]
    if _is_frect_xywh(args) or _is_rect_xywh(args):
        return args
    if _is_frect_topleft_size(args) or _is_rect_topleft_size(args):
        return args[0][0], args[0][1], args[1][0], args[1][1]
    elif _is_frect_frect_obj(args) or _is_rect_rect_obj(args):
        return (args.x, args.y, args.w, args.h) if isinstance(args, pg.Rect) else args.tuple()
    else:
        resources.log(resources.Severity.ERROR, resources.InvalidValue, f"Invalid arguments to {'F' if frect else ''}Rect constructor: {args}", frames_back=2)
    

class FRect:
    @overload
    def __init__(self, x: float, y: float, w: float, h: float, /) -> None: ...

    @overload
    def __init__(self, topleft: FCoordinateValue, size: FCoordinateValue, /) -> None: ...

    @overload
    def __init__(self, rect: FRectValue, /) -> None: ...

    def __init__(self, *args):
        if not (1 <= len(args) <= 4):
            resources.log(resources.Severity.ERROR, resources.InvalidValue, "FRect constructor takes 1 to 4 arguments")
        x, y, w, h = _validate_rect_args(args, True)
        self._x = x
        self._y = y
        self._w = w
        self._h = h

    def __repr__(self) -> str:
        return f"FRect({self.tuple()})"

    def tuple(self) -> tuple[float, float, float, float]:
        return (self._x, self._y, self._w, self._h)
    
    def __iter__(self) -> Iterator[float]:
        return iter(self.tuple())
    
    def __add__(self, other: FRect):
        if not isinstance(other, FRect):
            return NotImplemented
        return FRect(self.x + other.x, self.y + other.y, self.w + other.w, self.h + other.h)

    @property
    def x(self):
        return self._x

    @x.setter
    def x(self, new: float):
        self._x = new

    @property
    def y(self):
        return self._y

    @y.setter
    def y(self, new: float):
        self._y = new

    @property
    def w(self):
        return self._w

    @w.setter
    def w(self, new: float):
        self._w = new

    @property
    def h(self):
        return self._h

    @h.setter
    def h(self, new: float):
        self._h = new

    left = x
    top = y

    @property
    def right(self) -> float:
        return self._x + self._w
    
    @right.setter
    def right(self, new: float):
        self._x = new - self._w

    @property
    def bottom(self) -> float:
        return self._y + self._h
    
    @bottom.setter
    def bottom(self, new: float):
        self._y = new - self._h

    @property
    def topleft(self):
        return (self.x, self.y)
    
    @topleft.setter
    def topleft(self, new: FCoordinateValue):
        self.x, self.y = new

    @property
    def bottomleft(self):
        return (self.x, self.bottom)

    @bottomleft.setter
    def bottomleft(self, new: FCoordinateValue):
        self.x, self.bottom = new

    @property
    def topright(self):
        return (self.right, self.y)
    
    @topright.setter
    def topright(self, new: FCoordinateValue):
        self.right, self.y = new

    @property
    def bottomright(self):
        return (self.right, self.bottom)
    
    @bottomright.setter
    def bottomright(self, new: FCoordinateValue):
        self.right, self.bottom = new

    @property
    def center(self):
        return (self.x + self.w / 2, self.y + self.h / 2)
    
    @center.setter
    def center(self, new: FCoordinateValue):
        cx, cy = new
        self.x = cx - self.w / 2
        self.y = cy - self.h / 2

    def copy(self):
        return FRect(self.x, self.y, self.w, self.h)


class Rect:
    @overload
    def __init__(self, x: int, y: int, w: int, h: int, /) -> None: ...

    @overload
    def __init__(self, topleft: CoordinateValue, size: CoordinateValue, /) -> None: ...

    @overload
    def __init__(self, rect: RectValue, /) -> None: ...

    def __init__(self, *args):
        if not (1 <= len(args) <= 4):
            resources.log(resources.Severity.ERROR, resources.InvalidValue, "Rect constructor takes 1 to 4 arguments")
        x, y, w, h = _validate_rect_args(args)
        self._x = x
        self._y = y
        self._w = w
        self._h = h
        self._rect = pg.Rect(x, y, w, h)

    def __repr__(self) -> str:
        return f"Rect{self.tuple()}"

    def tuple(self) -> tuple[int, int, int, int]:
        return (self._x, self._y, self._w, self._h)

    def __iter__(self) -> Iterator[int]:
        return iter(self.tuple())

    def __add__(self, other: Rect):
        if not isinstance(other, Rect):
            return NotImplemented
        return Rect(self.x + other.x, self.y + other.y, self.w + other.w, self.h + other.h)

    @property
    def x(self):
        return self._x

    @x.setter
    def x(self, new: int):
        self._x = new
        self._rect.x = new

    @property
    def y(self):
        return self._y

    @y.setter
    def y(self, new: int):
        self._y = new
        self._rect.y = new

    @property
    def w(self):
        return self._w

    @w.setter
    def w(self, new: int):
        self._w = new
        self._rect.w = new

    @property
    def h(self):
        return self._h

    @h.setter
    def h(self, new: int):
        self._h = new
        self._rect.h = new

    left = x
    top = y

    @property
    def right(self) -> int:
        return self._x + self._w
    
    @right.setter
    def right(self, new: int):
        self._x = new - self._w
        self._rect.right = new

    @property
    def bottom(self) -> int:
        return self._y + self._h
    
    @bottom.setter
    def bottom(self, new: int):
        self._y = new - self._h
        self._rect.bottom = new

    @property
    def topleft(self):
        return (self.x, self.y)
    
    @topleft.setter
    def topleft(self, new: CoordinateValue):
        self.x, self.y = new

    @property
    def bottomleft(self):
        return (self.x, self.bottom)

    @bottomleft.setter
    def bottomleft(self, new: CoordinateValue):
        self.x, self.bottom = new

    @property
    def topright(self):
        return (self.right, self.y)
    
    @topright.setter
    def topright(self, new: CoordinateValue):
        self.right, self.y = new

    @property
    def bottomright(self):
        return (self.right, self.bottom)
    
    @bottomright.setter
    def bottomright(self, new: CoordinateValue):
        self.right, self.bottom = new

    @property
    def center(self):
        return (self.x + self.w // 2, self.y + self.h // 2)
    
    @center.setter
    def center(self, new: CoordinateValue):
        cx, cy = new
        self.x = cx - self.w // 2
        self.y = cy - self.h // 2

    def copy(self):
        return Rect(self.x, self.y, self.w, self.h)

def empty_rect():
    return Rect(0, 0, 0, 0)

def empty_frect():
    return FRect(0, 0, 0, 0)

def full_screen_rect():
    return (FRect(0, 0, 1, 1), empty_rect())

class Sprite:
    _cache: dict[Path, pg.Surface] = {}

    def __init__(
            self,
            source: Path | str,
            rect: RectValue | None = None
        ):
        self.source = Path(source)
        self.rect = rect

        self._surface: pg.Surface | None = None

    def load(self) -> pg.Surface:
        if self._surface is None:
            if self.source not in Sprite._cache:
                Sprite._cache[self.source] = pg.image.load(str(self.source)).convert_alpha()
            image = Sprite._cache[self.source]

            if self.rect is not None:
                image = image.subsurface(pg.Rect(
                    self.rect.tuple() if isinstance(self.rect, Rect) else self.rect
                )).copy()

            self._surface = image
        return self._surface
    
class Animation:
    def __init__(
        self,
        frames: Sequence[Path | str | Sprite],
        fps: int = 12,
        loop: bool = True,
    ):
        self.frames = [
            frame if isinstance(frame, Sprite) else Sprite(frame)
            for frame in frames
        ]

        if not self.frames:
            resources.log(resources.Severity.ERROR, resources.InvalidValue, "Animation needs at least one frame", frames_back=1)

        self.fps = fps
        self.loop = loop
        self.time = 0.0

    @property
    def current_frame(self) -> Sprite:
        index = int(self.time * self.fps)

        if self.loop:
            index %= len(self.frames)
        else:
            index = min(index, len(self.frames) - 1)

        return self.frames[index]
    
    @property
    def duration(self) -> float:
        return len(self.frames) / self.fps

    def update(self, dt: float):
        self.time += dt

        if self.loop:
            self.time %= self.duration

    def load(self) -> list[pg.Surface]:
        full: list[pg.Surface] = []
        for frame in self.frames:
            full.append(frame.load())
        return full

    @classmethod
    def from_folder(cls, folder: Path, /, *, prefix: str = "frame_"):
        paths = sorted(folder.glob(f"{prefix}*.png"))
        return cls(paths)
    
    @classmethod
    def from_spritesheet(
        cls,
        image_path: Path | str,
        frame_rects: list[RectValue],
        fps: int = 12,
    ):
        frames = [
            Sprite(image_path, rect)
            for rect in frame_rects
        ]

        return cls(frames, fps)
    
class SurfaceHandler:
    def __init__(
        self,
        surface: pg.Surface,
        pos: CoordinateValue,
        special_flags: int = 0
    ) -> None:
        self.surface = surface
        self.pos = pos
        self.special_flags = special_flags
    
    @property
    def rect(self) -> pg.Rect:
        return pg.Rect(self.pos, self.surface.get_size())

    def paste(self, base: pg.Surface, /):
        base.blit(self.surface, self.pos, special_flags=self.special_flags)

    def extend(self, other: "SurfaceHandler", /, *, clip_within_self: bool = False):
        if clip_within_self:
            offset = (
                other.pos[0] - self.pos[0],
                other.pos[1] - self.pos[1],
            )

            self.surface.blit(
                other.surface,
                offset,
                special_flags=other.special_flags,
            )
            return
        union = self.rect.union(other.rect)

        new_surface = pg.Surface(union.size, pg.SRCALPHA)

        self_offset = (
            self.rect.x - union.x,
            self.rect.y - union.y,
        )

        other_offset = (
            other.rect.x - union.x,
            other.rect.y - union.y,
        )

        new_surface.blit(self.surface, self_offset)
        new_surface.blit(
            other.surface,
            other_offset,
            special_flags=other.special_flags,
        )

        self.surface = new_surface
        self.pos = union.topleft

class Sound:
    _cache: dict[Path, pg.mixer.Sound] = {}

    def __init__(self, source: Path | str):
        self.source = Path(source)
        self._sound: pg.mixer.Sound | None = None

    def load(self) -> pg.mixer.Sound:
        if self._sound is None:
            path = self.source.resolve()
            if path not in Sound._cache:
                Sound._cache[path] = pg.mixer.Sound(str(path))
            self._sound = Sound._cache[path]
        return self._sound

    def play(self, loop_amt: int = 0, *, maxtime: int = 0, fade_ms: int = 0) -> pg.mixer.Channel:
        return self.load().play(loop_amt, maxtime, fade_ms)

    def stop(self):
        self.load().stop()

    def set_volume(self, volume: float):
        self.load().set_volume(volume)

    def get_volume(self) -> float:
        return self.load().get_volume()


__all__ = [
    "ColorValue",
    "RectValue",
    "FRectValue",
    "CoordinateValue",
    "FCoordinateValue",
    "Key",
    "MouseButton",
    "ControllerButton",
    "InputProfile",
    "BlendMode",
    "KeyValue",
    "MouseButtonValue",
    "ControllerButtonValue",
    "InputAction",
    "InputState",
    "FRect",
    "Rect",
    "empty_rect",
    "empty_frect",
    "full_screen_rect",
    "Sprite",
    "Animation",
    "SurfaceHandler",
    "Sound",
]
