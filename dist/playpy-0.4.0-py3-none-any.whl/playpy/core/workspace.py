from __future__ import annotations

from contextlib import contextmanager
import inspect
from pathlib import Path
from typing import Generator

import pygame as pg

from .elements import Scene, Element, SceneHandle
from .resources import DEFAULT_ICON_PATH, ControllerConnected, InvalidValue, log, require_init, Severity, _make_surface, quit
from .state import ColorValue, InputState, Key, MouseButton, ControllerButton, InputProfile, SurfaceHandler
from ..builtin import Padding, GlobalElement, Camera, Scrollable

class Workspace:
    def __init__(
        self,
        windowed_width: int = 800,
        windowed_height: int = 600,
        color: ColorValue = (255, 255, 255),
        fps: int = 60,
        name: str | None = None,
        icon: str | Path | None = None,
    ):
        require_init()

        self.windowed_size = (windowed_width, windowed_height)

        info = pg.display.Info()
        self.fullscreen_size = (info.current_w, info.current_h)

        self.size = self.windowed_size

        self.color = color
        self.fps = fps
        self.running = False
        self.name = name
        self.icon = icon

        self._children: list[Element] = []
        self._scene_stack: list[Scene] = []
        self._hovered_set: set[Element] = set()
        self._hovered_top: Element | None = None
        self._last_hovered_set: set[Element] = set()
        self._last_hovered_top: Element | None = None
        self._scene_changed = False
        self.previous_scene: Scene | None = None
        self.last_scene_change_time = 0.0
        self.scene_change_queue: list[Scene | None] = []
        self.scene_push_queue: list[tuple[Scene, bool]] = [] # (scene, is_push)
        self.coroutines: list[Generator[None, None, None]] = []
        self._stepping = False

        self.screen = pg.display.set_mode(self.size)
        self.clock = pg.time.Clock()

        if self.name:
            pg.display.set_caption(self.name)
        else:
            pg.display.set_caption("PlayPy Window")

        icon_path = Path(self.icon) if self.icon is not None else DEFAULT_ICON_PATH
        if icon_path and icon_path.exists():
            try:
                pg.display.set_icon(pg.image.load(icon_path))
            except Exception:
                pass

        # Input tracking
        self.input = InputState()
        self.controller_profiles: dict[InputProfile, int] = {} # profile -> instance_id
        self._joysticks: dict[int, pg.joystick.JoystickType] = {} # instance_id -> joystick
        self._profile_changes: list[tuple[InputProfile, bool]] = [] # (profile, is_connected)
        self._create_controller_profiles()
        
    @property
    def children(self) -> list[Element]:
        return self._children

    def add_child(self, child: Element, z: int | None = None) -> None:
        if z is not None:
            child.z = z
        child.parent = self

    def remove_child(self, child: Element) -> None:
        child.parent = None

    @property
    def current_scene(self) -> Scene | None:
        if not self._scene_stack:
            return None
        return self._scene_stack[-1]
    
    @property
    def profile_changes(self) -> list[tuple[InputProfile, bool]]:
        return self._profile_changes
    
    @property
    def profiles_added(self) -> list[InputProfile]:
        return [profile for profile, is_connected in self._profile_changes if is_connected]
    
    @property
    def profiles_removed(self) -> list[InputProfile]:
        return [profile for profile, is_connected in self._profile_changes if not is_connected]

    @property
    def scene_stack(self) -> list[Scene]:
        return self._scene_stack

    @property
    def scene_changed(self) -> bool:
        return self._scene_changed
    
    def is_ancestor_of(self, descendant: "Element") -> bool:
        return descendant.is_descendant_of(self)

    def is_parent_of(self, child: "Element") -> bool:
        return child._parent is self

    def _record_scene_change(self, old_scene: Scene | None, new_scene: Scene | None) -> None:
        if old_scene is not new_scene:
            self.previous_scene = old_scene
            self._scene_changed = True
            self.last_scene_change_time = self.input.runtime

    def _resolve_queued_scene_change(self):
        if not self.scene_change_queue:
            return
        old_scene = self.current_scene
        while self._scene_stack:
            old = self._scene_stack.pop()
            try:
                old.on_exit(self)
            finally:
                self.remove_child(old)

        final_scene: Scene | None = None
        while self.scene_change_queue:
            scene = self.scene_change_queue.pop(0)
            if final_scene is not None:
                try:
                    final_scene.on_exit(self)
                finally:
                    self.remove_child(final_scene)
                final_scene = None

            if scene is None:
                final_scene = None
                continue

            self._scene_stack.append(scene)
            scene.parent = self
            scene.on_enter(self)
            final_scene = scene

        self._record_scene_change(old_scene, final_scene)

    def queue_scene_change(self, scene: Scene | None) -> None:
        self.scene_change_queue.append(scene)

    def _resolve_queued_scene_push(self):
        while self.scene_push_queue:
            scene, is_push = self.scene_push_queue.pop(0)
            if not is_push:
                if not self._scene_stack:
                    continue
                popped = self._scene_stack.pop()
                try:
                    popped.on_exit(self)
                finally:
                    self.remove_child(popped)
                current = self.current_scene
                if current is not None:
                    current.on_resume(self)
                self._record_scene_change(popped, current)
            else:
                current = self.current_scene
                if current is not None:
                    current.on_pause(self)
                self._scene_stack.append(scene)
                scene.parent = self
                scene.on_enter(self)
                self._record_scene_change(current, scene)

    def queue_scene_push(self, scene: Scene) -> None:
        self.scene_push_queue.append((scene, True))

    def queue_scene_pop(self, scene: Scene | None = None) -> None:
        if scene is not None and scene not in self._scene_stack:
            log(Severity.ERROR, InvalidValue, "Cannot remove scene from stack as scene isn't in stack.", frames_back=1)
        if not self._scene_stack:
            log(Severity.ERROR, InvalidValue, "Cannot remove scene from stack as stack is empty.", frames_back=1)
        scene = scene or self._scene_stack[-1]
        self.scene_push_queue.append((scene, False))

    @contextmanager
    def scene_scope(self, scene: Scene):
        handle = SceneHandle(self, scene)
        self.queue_scene_push(scene)

        try:
            yield scene, handle
        finally:
            handle.disconnect()

    def get_element_rect(self, element: Element) -> pg.Rect:
        parent = element.parent
        if isinstance(parent, Element):
            parent_rect = self.get_element_rect(parent)
            layout_rect = parent_rect.copy()

            if not element.ignores_environment:
                camera = parent.get_component(Camera)
                if camera is not None:
                    layout_rect.x -= int(camera.x)
                    layout_rect.y -= int(camera.y)

                scrollable = parent.get_component(Scrollable)
                if scrollable is not None:
                    layout_rect.x -= int(scrollable.x)
                    layout_rect.y -= int(scrollable.y)
        else:
            parent_rect = pg.Rect((0, 0), self.size)
            layout_rect = parent_rect.copy()

        padding = element.parent.get_component(Padding) if isinstance(element.parent, Element) and not element.ignores_environment else None

        rect_x = round(element.scale.x * layout_rect.w) + element.offset.x + layout_rect.x
        rect_y = round(element.scale.y * layout_rect.h) + element.offset.y + layout_rect.y
        rect_w = round(element.scale.w * layout_rect.w) + element.offset.w
        rect_h = round(element.scale.h * layout_rect.h) + element.offset.h

        rect = pg.Rect(rect_x, rect_y, rect_w, rect_h)

        if padding:
            pad_x = round(padding.scale * parent_rect.w) + padding.offset
            pad_y = round(padding.scale * parent_rect.h) + padding.offset

            inner_rect = parent_rect.inflate(-pad_x * 2, -pad_y * 2)

            # Left side
            dist = None
            if rect.x < parent_rect.x:
                dist = inner_rect.x - parent_rect.x
            elif rect.x < inner_rect.x:
                dist = inner_rect.x - rect.x
            if dist:
                rect.x += dist
                rect.w -= dist

            # Right side
            if rect.right > parent_rect.right:
                rect.w += inner_rect.right - parent_rect.right
            elif rect.right > inner_rect.right:
                rect.w = inner_rect.right - rect.x

            # Top side
            dist = None
            if rect.y < parent_rect.y:
                dist = inner_rect.y - parent_rect.y
            elif rect.y < inner_rect.y:
                dist = inner_rect.y - rect.y
            if dist:
                rect.y += dist
                rect.h -= dist

            # Bottom side
            if rect.bottom > parent_rect.bottom:
                rect.h += inner_rect.bottom - parent_rect.bottom
            elif rect.bottom > inner_rect.bottom:
                rect.h = inner_rect.bottom - rect.y

        rect.w = max(rect.w, 0)
        rect.h = max(rect.h, 0)

        return rect

    def _clips_descendants(self, element: Element) -> bool:
        return isinstance(element, Scene) or getattr(element, "scrollable", False)

    def _point_within_clip_ancestors(self, element: Element, point: tuple[int, int]) -> bool:
        parent = element.parent
        while isinstance(parent, Element):
            if self._clips_descendants(parent):
                if not self.get_element_rect(parent).collidepoint(point):
                    return False
            parent = parent.parent
        return True

    def _ensure_controller_profile_state(self, profile: InputProfile):
        self.input.controller_buttons_pressed.setdefault(profile, set())
        self.input.controller_buttons_pressed_last_frame.setdefault(profile, set())
        self.input.controller_left_sticks.setdefault(profile, (0.0, 0.0))
        self.input.controller_right_sticks.setdefault(profile, (0.0, 0.0))
        self.input.controller_left_sticks_last_frame.setdefault(profile, (0.0, 0.0))
        self.input.controller_right_sticks_last_frame.setdefault(profile, (0.0, 0.0))

    def _profile_from_instance_id(self, instance_id: int) -> InputProfile | None:
        for profile, profile_instance_id in self.controller_profiles.items():
            if profile_instance_id == instance_id:
                return profile
        return None
    
    def _create_controller_profiles(self):
        for device_index in range(pg.joystick.get_count()):
            joystick = pg.joystick.Joystick(device_index)
            self._add_controller_profile(joystick.get_instance_id(), joystick)

    def _add_controller_profile(self, instance_id: int, joystick: pg.joystick.JoystickType | None = None):
        existing_profile = self._profile_from_instance_id(instance_id)
        if existing_profile is not None:
            if joystick is not None:
                self._joysticks[instance_id] = joystick
            self._ensure_controller_profile_state(existing_profile)
            return

        # Find lowest unused profile index
        existing_indices = {profile.value for profile in self.controller_profiles}
        new_index = 0
        while new_index in existing_indices:
            new_index += 1
        new_profile = InputProfile(new_index)
        self.controller_profiles[new_profile] = instance_id
        if joystick is not None:
            self._joysticks[instance_id] = joystick
        self._ensure_controller_profile_state(new_profile)
        self._profile_changes.append((new_profile, True))
        log(Severity.INFO, ControllerConnected, f"Controller connected with instance ID {instance_id} assigned to profile {new_profile}.")

    def _remove_controller_profile(self, instance_id: int):
        profile_to_remove = None
        for profile, id in self.controller_profiles.items():
            if id == instance_id:
                profile_to_remove = profile
                break
        if profile_to_remove is not None:
            del self.controller_profiles[profile_to_remove]
            joystick = self._joysticks.pop(instance_id, None)
            if joystick is not None:
                joystick.quit()
            self.input.controller_buttons_pressed.pop(profile_to_remove, None)
            self.input.controller_buttons_pressed_last_frame.pop(profile_to_remove, None)
            self.input.controller_left_sticks.pop(profile_to_remove, None)
            self.input.controller_right_sticks.pop(profile_to_remove, None)
            self.input.controller_left_sticks_last_frame.pop(profile_to_remove, None)
            self.input.controller_right_sticks_last_frame.pop(profile_to_remove, None)
            self._profile_changes.append((profile_to_remove, False))
            log(Severity.INFO, ControllerConnected, f"Controller with instance ID {instance_id} and profile {profile_to_remove} disconnected.")

    def _controller_event_profile(self, event: pg.event.Event) -> InputProfile | None:
        instance_id = getattr(event, "instance_id", getattr(event, "which", None))
        if instance_id is not None:
            profile = self._profile_from_instance_id(instance_id)
            if profile is not None:
                return profile

        device_index = getattr(event, "joy", None)
        if device_index is not None and device_index < pg.joystick.get_count():
            joystick = pg.joystick.Joystick(device_index)
            return self._profile_from_instance_id(joystick.get_instance_id())

        return None

    def update_input(self):
        self.input.text_input = []
        self.input.mouse_wheel = 0
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.input.quit = True
            else:
                self.input.quit = False

            if event.type == pg.KEYDOWN:
                self.input.keys_pressed.add(Key.from_pygame(event.key))
            elif event.type == pg.KEYUP:
                self.input.keys_pressed.discard(Key.from_pygame(event.key))

            elif event.type == pg.MOUSEBUTTONDOWN:
                self.input.mouse_buttons_pressed.add(MouseButton.from_pygame(event.button))
            elif event.type == pg.MOUSEBUTTONUP:
                self.input.mouse_buttons_pressed.discard(MouseButton.from_pygame(event.button))

            elif event.type == pg.JOYBUTTONDOWN or event.type == pg.CONTROLLERBUTTONDOWN:
                profile = self._controller_event_profile(event)
                if profile is not None:
                    self._ensure_controller_profile_state(profile)
                    self.input.controller_buttons_pressed[profile].add(ControllerButton.from_pygame(event.button))
            elif event.type == pg.JOYBUTTONUP or event.type == pg.CONTROLLERBUTTONUP:
                profile = self._controller_event_profile(event)
                if profile is not None:
                    self._ensure_controller_profile_state(profile)
                    self.input.controller_buttons_pressed[profile].discard(ControllerButton.from_pygame(event.button))
            elif event.type == pg.JOYAXISMOTION:
                profile = self._controller_event_profile(event)
                if profile is not None:
                    self._ensure_controller_profile_state(profile)
                    axis = event.axis
                    value = event.value
                    if axis == 0:
                        self.input.controller_left_sticks[profile] = (value, self.input.controller_left_sticks[profile][1])
                    elif axis == 1:
                        self.input.controller_left_sticks[profile] = (self.input.controller_left_sticks[profile][0], value)
                    elif axis == 2:
                        self.input.controller_right_sticks[profile] = (value, self.input.controller_right_sticks[profile][1])
                    elif axis == 3:
                        self.input.controller_right_sticks[profile] = (self.input.controller_right_sticks[profile][0], value)
                    elif axis == 4:
                        if value < -0.5:
                            self.input.controller_buttons_pressed[profile].discard(ControllerButton.LEFTTRIGGER)
                        elif value > 0.5:
                            self.input.controller_buttons_pressed[profile].add(ControllerButton.LEFTTRIGGER)
                    elif axis == 5:
                        if value < -0.5:
                            self.input.controller_buttons_pressed[profile].discard(ControllerButton.RIGHTTRIGGER)
                        elif value > 0.5:
                            self.input.controller_buttons_pressed[profile].add(ControllerButton.RIGHTTRIGGER)

            elif event.type == pg.JOYHATMOTION:
                profile = self._controller_event_profile(event)
                if profile is not None:
                    self._ensure_controller_profile_state(profile)
                    buttons = self.input.controller_buttons_pressed[profile]
                    buttons.discard(ControllerButton.DPAD_UP)
                    buttons.discard(ControllerButton.DPAD_DOWN)
                    buttons.discard(ControllerButton.DPAD_LEFT)
                    buttons.discard(ControllerButton.DPAD_RIGHT)

                    x, y = event.value
                    if x < 0:
                        buttons.add(ControllerButton.DPAD_LEFT)
                    elif x > 0:
                        buttons.add(ControllerButton.DPAD_RIGHT)
                    if y < 0:
                        buttons.add(ControllerButton.DPAD_DOWN)
                    elif y > 0:
                        buttons.add(ControllerButton.DPAD_UP)

            elif event.type == pg.MOUSEMOTION:
                self.input.mouse_pos = event.pos
            elif event.type == pg.TEXTINPUT:
                if event.text:
                    self.input.text_input.append(event.text)
            elif event.type == pg.MOUSEWHEEL:
                self.input.mouse_wheel += event.y

            elif event.type == pg.JOYDEVICEADDED or event.type == pg.CONTROLLERDEVICEADDED:
                device_index = getattr(event, "device_index", getattr(event, "which", None))
                if device_index is not None:
                    joystick = pg.joystick.Joystick(device_index)
                    self._add_controller_profile(joystick.get_instance_id(), joystick)

            elif event.type == pg.JOYDEVICEREMOVED or event.type == pg.CONTROLLERDEVICEREMOVED:
                instance_id = getattr(event, "instance_id", getattr(event, "which", None))
                if instance_id is not None:
                    self._remove_controller_profile(instance_id)

    def _is_element_hittable(self, element: Element) -> bool:
        if not element.visible:
            return False
        rect = element.get_rect_px(self)
        if rect.w <= 0 or rect.h <= 0:
            return False
        if not rect.collidepoint(self.input.mouse_pos):
            return False
        return self._point_within_clip_ancestors(element, self.input.mouse_pos)

    def _update_hover_state(self, draw_order: list[Element]) -> None:
        self._last_hovered_set = self._hovered_set
        self._last_hovered_top = self._hovered_top

        hovered: list[Element] = []
        for element in draw_order:
            if self._is_element_hittable(element) and not element.ignores_environment:
                hovered.append(element)
        self._hovered_set = set(hovered)
        self._hovered_top = hovered[-1] if hovered else None

    def generate_processing_order(self, target: Element | None = None):
        order: list[Element] = []
        if target is None:
            targ = self
        else:
            targ = target
            order.append(targ)

        for child in sorted(targ.children, key=lambda x: x.z):
            order.extend(self.generate_processing_order(child))
        return order
    
    def generate_global_processing_order(self) -> list[Element]:
        # Generate processing order for elements that are in the workspace but not in the current scene, AND have the global component
        order: list[Element] = []
        for child in sorted(self._children, key=lambda x: x.z):
            if child is not self.current_scene and child.get_component(GlobalElement):
                order.extend(self.generate_processing_order(child))
        return order

    def _base_processing_order(self) -> list[Element]:
        scene = self.current_scene
        if scene is not None:
            return self.generate_processing_order(scene) + self.generate_global_processing_order()
        return self.generate_processing_order()

    def is_mouse_over(self, element: Element) -> bool:
        return element in self._hovered_set

    def is_mouse_top(self, element: Element) -> bool:
        return self._hovered_top is element

    def just_hovered_inclusive(self, element: Element) -> bool:
        return element in self._hovered_set and element not in self._last_hovered_set

    def just_hovered(self, element: Element) -> bool:
        return self._hovered_top is element and self._last_hovered_top is not element

    def just_unhovered_inclusive(self, element: Element) -> bool:
        return element not in self._hovered_set and element in self._last_hovered_set

    def just_unhovered(self, element: Element) -> bool:
        return self._hovered_top is not element and self._last_hovered_top is element

    def draw_element(self, element: Element, parent_handler: SurfaceHandler | None):
        if not element.visible: return
        drawn_handler = element.draw(self, parent_handler)

        current_handler = drawn_handler if drawn_handler is not None else parent_handler

        for child in sorted(element.children, key=lambda c: c.z):
            child_handler = self.draw_element(child, current_handler)

            if current_handler is not None and child_handler is not None:
                current_handler.extend(
                    child_handler,
                    clip_within_self=not child.ignores_environment,
                )

        return current_handler if drawn_handler is not None else None
    
    def draw(self):
        workspace_handler = SurfaceHandler(
            _make_surface(self.screen.size),
            (0, 0)
        )

        scene = self.current_scene
        sorted_children = sorted(self.children, key=lambda c: c.z)
        if scene is not None:
            sorted_children = [scene] + [child for child in sorted_children if child is not scene and child.get_component(GlobalElement)]

        for child in sorted_children:
            child_handler = self.draw_element(child, workspace_handler)
            if child_handler is not None:
                workspace_handler.extend(child_handler, clip_within_self=True)

        workspace_handler.paste(self.screen)

    def step(self):
        self._stepping = True
        self.screen.fill(self.color)

        try:
            self._resolve_queued_scene_change()
            self._resolve_queued_scene_push()

            base_order = self._base_processing_order()
            self.update_input()

            alive_coroutines = []

            for coroutine in self.coroutines:
                try:
                    next(coroutine)
                    alive_coroutines.append(coroutine)
                except StopIteration:
                    pass

            self.coroutines = alive_coroutines

            self._update_hover_state(base_order)

            for inp_target in reversed(base_order):
                if not inp_target.enabled or (
                    inp_target.block_input_when_occluded
                    and self.is_mouse_over(inp_target)
                    and not self.is_mouse_top(inp_target)
                ):
                    continue

                result = inp_target.handle_input(self)

                if inspect.isgenerator(result):
                    self.coroutines.append(result)

            self.draw()

            pg.display.flip()
            self.input.next_frame(self.clock.tick(self.fps) / 1000)
            self._scene_changed = False
            self._profile_changes.clear()
        finally:
            self._stepping = False

    def run(self):
        self.running = True
        while self.running:
            self.step()
        quit()

    def wait(self, seconds: float):
        if self._stepping or not self.running:
            pg.time.wait(round(seconds * 1000))
            return

        end_time = pg.time.get_ticks() + round(seconds * 1000)
        while self.running and pg.time.get_ticks() < end_time:
            self.step()

    def quit(self):
        self.running = False
        self.input.quit = True

__all__ = [
    "Workspace"
]
